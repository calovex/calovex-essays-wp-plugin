<?php 
/* Template Name: PageWithoutSidebar */ 
?>