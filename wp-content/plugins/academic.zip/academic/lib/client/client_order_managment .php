<?php
//Dependencies 
require '../../../../../wp-load.php';


class client_order_management 
{
//Constructor 
    function __constructor()
    {
        
    }

	//Add orders
	function add_orders ($customer_id,$product_id,$amount,$topic,$doctype,$date,$writer_level,$spacing,$number_of_pages,$one_page_summary, 
	                     $subject_area,$academic_level,$reference_style,$number_of_references,$prefered_language,$order_description,
						 $order_status,$paper_type)	 
	{
		global $wpdb;
		$table_name=$wpdb->prefix.'posts';
		$entries=array(
				  'product_id'=>$product_id,  
				  'amount'=>$amount,
				  'topic'=>$topic,
				  'doctype'=>$doctype,
				  'date_required'=>$date,
				  'writerlevel'=>$writer_level,
				  'spacing'=>$spacing,  
				  'number_of_pages'=>$number_of_pages, 
				  'one_page_summary'=>$one_page_summary,
				  'subject_area'=>$subject_area,
				  'academic_level'=>$academic_level,
				  'reference_style'=>$reference_style,
				  'number_of_references'=>$number_of_references,
				  'prefered_language'=>$prefered_language,
				  'order_description'=>$order_description,
				  'processing'=>$order_status,				 
				  'papertype'=>$paper_type,  			  
				  'customer_id'=>$customer_id				               
						);		
	
		$wpdb->insert($table_name,$entries);
		var_dump($wpdb);
	    $wpdb->last_error ;
		$wpdb->last_query;
		echo 'The id is xcvxcv bbbbbbbbbbbbbbbb'.$wpdb->insert_id;
$wpdb->print_error();
$wpdb->show_errors(); 
		

	}
	// Test addition 
	function add_ordersx ($customer_id,$product_id,$amount,$topic)	 
{
global $wpdb;
$table_name=$wpdb->prefix.'posts';
$entries=array(
'product_id'=>$product_id,  
'amount'=>$amount,
'topic'=>$topic,
'customer_id'=>$customer_id				               
   );		

$wpdb->insert($table_name,$entries);

echo 'ThefuffsfaFbbb'.$wpdb->insert_id;
$wpdb->print_error();
$wpdb->show_errors(); 


}
	
	// Add payment 
	function payment($order_id,$transaction_id,$amount,$payment_method,$customer_id,$transaction_date,$first_name,$last_name,$email)
	{//beginning of payment fuction
	
			$table_name="billing";
			$entries=array(			
				  'order_id' =>$order_id,
				  'transaction_id'=>$transaction_id,
				  'amount'=>$amount,
				  'payment_method'=>$payment_method,
				  'customer_id'=>$customer_id,
				  'transaction_date'=>$transaction_date,
				  'first_name'=>$first_name,
				  'last_name'=>$last_name,
				  'email'=>$email);
		
		wp_inset_data($table_name,$entries);
		
	}// end of payment function
	
		
	//CORE INSERT FUNCTION 	
	function wp_inset_data($table_name,$entries)	
	{
		$table_name = $wpdb->prefix .$table_name;
		$wpdb->insert($table_name, $entries);
	}
	
	
	
} // End of class 

//Adding data to the database
/* TESTING DATA
$orders=new client_order_management();
$done2=$orders->add_orders("987","404",'34','topic','doctype','23-11-2020','writer_level','spacing','number_of_pages','0', 
	                     'subject_area','academic_level','Harvard','number_of_references','prefered_language','order_description',
						 'order_status','paper_type');
 $done=$orders->add_ordersX("987","404",'34','thE TOPIC IS GOOD');	 
 */



?>