<?php
class order_placement{
     
    //Store Customer
    //Data will be stored in wp users table
    function store_customer($con)
    {
       
       $sql="INSERT INTO `customers`(`first_name`,`last_name`,`email`,`password`,`country`,`country_id`,`area_code`,`phone_number`,`date_of_joining`) 
                VALUES (?,?,?,?,?,?,?,?,?)"; 
        $stmt= $con->prepare($sql);
        

        $stmt->bind_param("sssssssss", $first_name, $last_name,$email,$password,
        $country,
        $country_code,
        $area_code,
        $phone_number,
        $registration_date);


        $stmt->execute();    
        
        
        $error = $mysqli->errno . 'xxzcczxczxczxcxzcxZs ' . $mysqli->error;
        echo $error;
        
        if($insert_customer){
            
        $CUSTOMER_ID=$link->insert_id;  // the row inserted
        }
    }

    //Store Order

    //Store files

    //Store Payment 

    

}

?>