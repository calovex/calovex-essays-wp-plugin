<?php
//Database Connection
class database{
	
  private $host;
  private $user;
  private $pass;
  private $db;
  public $mysqli;

  public function __construct() {
    $this->db_connect();
   // $this->pdo_db_connect();
  }

  private function db_connect(){
	 
    $this->host = 'localhost';
    $this->user = 'root';
    $this->pass = '';
    $this->db = 'academic';

   // $this->mysqli = new mysqli($this->host, $this->user, $this->pass, $this->db);
    //return $this->mysqli;
  }
  
  private function pdo_db_connect()
  {  
  	$host = 'localhost';
		$user = 'root';
		$pass = '';
		$db = 'academic';
		
		$link = new PDO("mysql:host=$host ;dbname=$db", $user, $pass);
  }


  public function getmyDB()
  {
    $this->host = 'localhost';
    $this->user = 'root';
    $this->pass = '';
    $this->db = 'academic';

    $this->mysqli = new mysqli($this->host, $this->user, $this->pass, $this->db);
    return $this->mysqli;
  }
 
}



?>