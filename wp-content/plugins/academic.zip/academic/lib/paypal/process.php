<?php
include_once("config.php");
include_once("paypal.class.php");

$paymentType = 'Auth'; // Payment type

$paypalmode = ($PayPalMode=='sandbox') ? '.sandbox' : '';

if($_POST) //Post Data received from product list page.
{
	//Mainly we need 4 variables from product page Item Name, Item Price, Item Number and Item Quantity.
	//Please Note : People can manipulate hidden field amounts in form,
	//In practical world you must fetch actual price from database using item id. Eg: 
	//$ItemPrice = $mysqli->query("SELECT item_price FROM products WHERE id = Product_Number");

		
	$email =$_POST["email"];
	$firstname='boy example';//$_POST["first_name"];
	$lastname='alex';//$_POST["last_name"];	
	$password=1221123;//$_POST["password"];
	$country='kenya';//$_POST["country"];
	$countrycode=213;//$_POST["country_code"];
	$areacode=2312;//$_POST["area_code"];
	$phonenumber=3345354353;//$_POST["phone_number"];
	
			
			
    // paper details
	$topic=$_POST["topic"];

	$type_of_document='literatre';//$_POST["itemname"];
	$academic_level=$_POST["academic_level"];
	$urgency=$_POST["urgency"];	
	$spacing=$_POST["spacing"];	
	$reference_style=$_POST["reference_style"];
	$language=$_POST["language"];	
	$references=$_POST["references"];	
    $description=$_POST["description"];	
	$subject=$_POST["subject"];
	
	//order details
	$ItemName 		= 'product 1';//$_POST["itemname"];//$_POST["itemname"]; //Item Name
	$ItemPrice 		= $_POST["itemprice"]; //Item Price
	$ItemNumber 	= $_POST["itemnumber"];//$_POST["itemnumber"]; //Item Number
	$ItemDesc 		=$subject; //$_POST["itemdesc"]"; //Item Number
					   
	$ItemQty 		= $_POST["itemQty"]; // Item Quantity
	$ItemTotalPrice = ($ItemPrice*$ItemQty); //(Item Price x Quantity = Total) Get total amount of product; 
	

	//discount	
	//Other important variables like tax, shipping cost
	$TotalTaxAmount 	= 0;  //Sum of tax for all items in this order. 
	$HandalingCost 		= 0;  //Handling cost for this order.
	$InsuranceCost 		= 0;  //shipping insurance cost for this order.
	$ShippinDiscount 	= 0; //Shipping discount for this order. Specify this as negative number.
	$ShippinCost 		= 0; //Although you may change the value later, try to pass in a shipping amount that is reasonably accurate.
	
	//Grand total including all tax, insurance, shipping cost and discount
	$GrandTotal = $ItemTotalPrice;//($ItemTotalPrice + $TotalTaxAmount + $HandalingCost + $InsuranceCost + $ShippinCost + $ShippinDiscount);
	
	//Parameters for SetExpressCheckout, which will be sent to PayPal
	$padata = 	'&METHOD=SetExpressCheckout'.
				'&RETURNURL='.urlencode($PayPalReturnURL ).
				'&CANCELURL='.urlencode($PayPalCancelURL).
				'&PAYMENTREQUEST_0_PAYMENTACTION='.urlencode("SALE").
				
				'&L_PAYMENTREQUEST_0_NAME0='.urlencode($ItemName).
				'&L_PAYMENTREQUEST_0_NUMBER0='.urlencode($ItemNumber).
				'&L_PAYMENTREQUEST_0_DESC0='.urlencode($ItemDesc).
				'&L_PAYMENTREQUEST_0_AMT0='.urlencode($ItemPrice).
				'&L_PAYMENTREQUEST_0_QTY0='. urlencode($ItemQty).
				
				/* 
				//Additional products (L_PAYMENTREQUEST_0_NAME0 becomes L_PAYMENTREQUEST_0_NAME1 and so on)
				'&L_PAYMENTREQUEST_0_NAME1='.urlencode($ItemName2).
				'&L_PAYMENTREQUEST_0_NUMBER1='.urlencode($ItemNumber2).
				'&L_PAYMENTREQUEST_0_DESC1='.urlencode($ItemDesc2).
				'&L_PAYMENTREQUEST_0_AMT1='.urlencode($ItemPrice2).
				'&L_PAYMENTREQUEST_0_QTY1='. urlencode($ItemQty2).
				*/
				
				/* 
				//Override the buyer's shipping address stored on PayPal, The buyer cannot edit the overridden address.
				'&ADDROVERRIDE=1'.
				'&PAYMENTREQUEST_0_SHIPTONAME=J Smith'.
				'&PAYMENTREQUEST_0_SHIPTOSTREET=1 Main St'.
				'&PAYMENTREQUEST_0_SHIPTOCITY=San Jose'.
				'&PAYMENTREQUEST_0_SHIPTOSTATE=CA'.
				'&PAYMENTREQUEST_0_SHIPTOCOUNTRYCODE=US'.
				'&PAYMENTREQUEST_0_SHIPTOZIP=95131'.
				'&PAYMENTREQUEST_0_SHIPTOPHONENUM=408-967-4444'.
				*/
				
				'&NOSHIPPING=1'. //set 1 to hide buyer's shipping address, in-case products that does not require shipping
				
				'&PAYMENTREQUEST_0_ITEMAMT='.urlencode($ItemTotalPrice).
				//'&PAYMENTREQUEST_0_TAXAMT='.urlencode($TotalTaxAmount).
				//'&PAYMENTREQUEST_0_SHIPPINGAMT='.urlencode($ShippinCost).
				//'&PAYMENTREQUEST_0_HANDLINGAMT='.urlencode($HandalingCost).
				//'&PAYMENTREQUEST_0_SHIPDISCAMT='.urlencode($ShippinDiscount).
				//'&PAYMENTREQUEST_0_INSURANCEAMT='.urlencode($InsuranceCost).
				'&PAYMENTREQUEST_0_AMT='.urlencode($GrandTotal).
				'&PAYMENTREQUEST_0_CURRENCYCODE='.urlencode($PayPalCurrencyCode).
				'&LOCALECODE=GB'. //PayPal pages to match the language on your website.
				'&LOGOIMG=http:../paypal/Image/logo2.png'. //site logo
				'&CARTBORDERCOLOR=FFFFFF'. //border color of cart
				'&ALLOWNOTE=1';
				
				############# set session variable we need later for "DoExpressCheckoutPayment" #######
				$_SESSION['ItemName'] 			=  $ItemName; //Item Name
				$_SESSION['ItemPrice'] 			=  $ItemPrice; //Item Price
				$_SESSION['ItemNumber'] 		=  $ItemNumber; //Item Number
				$_SESSION['ItemDesc'] 			=  $ItemDesc; //Item Number
				$_SESSION['ItemQty'] 			=  $ItemQty; // Item Quantity
				$_SESSION['ItemTotalPrice'] 	=  $ItemTotalPrice; //(Item Price x Quantity = Total) Get total amount of product; 
				$_SESSION['TotalTaxAmount'] 	=  $TotalTaxAmount;  //Sum of tax for all items in this order. 
				$_SESSION['HandalingCost'] 		=  $HandalingCost;  //Handling cost for this order.
				$_SESSION['InsuranceCost'] 		=  $InsuranceCost;  //shipping insurance cost for this order.
				$_SESSION['ShippinDiscount'] 	=  $ShippinDiscount; //Shipping discount for this order. Specify this as negative number.
				$_SESSION['ShippinCost'] 		=   $ShippinCost; //Although you may change the value later, try to pass in a shipping amount that is reasonably accurate.
				$_SESSION['GrandTotal'] 		=  $GrandTotal;

				//CUSTOMER DETAILS
				$_SESSION['email'] 			 =	$email;
				$_SESSION['first_name']		 =	$firstname;
				$_SESSION['last_name']		 =	$lastname;	
				$_SESSION['password'] 		 =	$password;
				$_SESSION['country']		 =	$country;
				$_SESSION['country_code']	 =	$countrycode;
				$_SESSION['area_code']		 =  $areacode;
				$_SESSION['phone_number']	 =	$phonenumber;
				
				
				//order details
			    $_SESSION["topic"]=$topic;

			    $_SESSION["document_type"]=$type_of_document;
				
				$_SESSION["academic_level"]=$academic_level;
				$_SESSION["urgency"]=$urgency;
				
				$_SESSION["spacing"]=$spacing;
				
				$_SESSION["reference_style"]=$reference_style;
				
				$_SESSION["language"]=$language;
				
				$_SESSION["references"]=$references;
				
				$_SESSION["description"]=$description;
				
				$_SESSION["subject"]=$subject;
				
		//We need to execute the "SetExpressCheckOut" method to obtain paypal token
		$paypal= new MyPayPal();
		$httpParsedResponseAr = $paypal->PPHttpPost('SetExpressCheckout', $padata, $PayPalApiUsername, $PayPalApiPassword, $PayPalApiSignature, $PayPalMode);
		
		//Respond according to message we receive from Paypal
		if("SUCCESS" == strtoupper($httpParsedResponseAr["ACK"]) || "SUCCESSWITHWARNING" == strtoupper($httpParsedResponseAr["ACK"]))
		{

				//Redirect user to PayPal store with Token received.
			 	$paypalurl ='https://www'.$paypalmode.'.paypal.com/cgi-bin/webscr?cmd=_express-checkout&token='.$httpParsedResponseAr["TOKEN"].'';
				header('Location: '.$paypalurl);
			 
		}else{
			//Show error message
			echo '<div style="color:red;"><b>Error : </b>'.urldecode($httpParsedResponseAr["L_LONGMESSAGE0"]).'</div>';
			echo '<pre>';
			print_r($httpParsedResponseAr);
			echo '</pre>';
		}

}

//Paypal redirects back to this page using ReturnURL, We should receive TOKEN and Payer ID
if(isset($_GET["token"]) && isset($_GET["PayerID"]))
{
	//we will be using these two variables to execute the "DoExpressCheckoutPayment"
	//Note: we haven't received any payment yet.
	
	$token = $_GET["token"];
	$payer_id = $_GET["PayerID"];
	
	//get session variables
	$ItemName 			= $_SESSION['ItemName']; //Item Name
	$ItemPrice 			= $_SESSION['ItemPrice'] ; //Item Price
	$ItemNumber 		= $_SESSION['ItemNumber']; //Item Number
	$ItemDesc 			= $_SESSION['ItemDesc']; //Item Number
	$ItemQty 			= $_SESSION['ItemQty']; // Item Quantity
	$ItemTotalPrice 	= $_SESSION['ItemTotalPrice']; //(Item Price x Quantity = Total) Get total amount of product; 
	$TotalTaxAmount 	= $_SESSION['TotalTaxAmount'] ;  //Sum of tax for all items in this order. 
	$HandalingCost 		= $_SESSION['HandalingCost'];  //Handling cost for this order.
	$InsuranceCost 		= $_SESSION['InsuranceCost'];  //shipping insurance cost for this order.
	$ShippinDiscount 	= $_SESSION['ShippinDiscount']; //Shipping discount for this order. Specify this as negative number.
	$ShippinCost 		= $_SESSION['ShippinCost']; //Although you may change the value later, try to pass in a shipping amount that is reasonably accurate.
	$GrandTotal 		= $_SESSION['GrandTotal'];
	
		

	$padata = 	'&TOKEN='.urlencode($token).
				'&PAYERID='.urlencode($payer_id).
				'&PAYMENTREQUEST_0_PAYMENTACTION='.urlencode("SALE").
				
				//set item info here, otherwise we won't see product details later	
				'&L_PAYMENTREQUEST_0_NAME0='.urlencode($ItemName).
				'&L_PAYMENTREQUEST_0_NUMBER0='.urlencode($ItemNumber).
				'&L_PAYMENTREQUEST_0_DESC0='.urlencode($ItemDesc).
				'&L_PAYMENTREQUEST_0_AMT0='.urlencode($ItemPrice).
				'&L_PAYMENTREQUEST_0_QTY0='. urlencode($ItemQty).

				/* 
				//Additional products (L_PAYMENTREQUEST_0_NAME0 becomes L_PAYMENTREQUEST_0_NAME1 and so on)
				'&L_PAYMENTREQUEST_0_NAME1='.urlencode($ItemName2).
				'&L_PAYMENTREQUEST_0_NUMBER1='.urlencode($ItemNumber2).
				'&L_PAYMENTREQUEST_0_DESC1=Description text'.
				'&L_PAYMENTREQUEST_0_AMT1='.urlencode($ItemPrice2).
				'&L_PAYMENTREQUEST_0_QTY1='. urlencode($ItemQty2).
				*/

				'&PAYMENTREQUEST_0_ITEMAMT='.urlencode($ItemTotalPrice).
				'&PAYMENTREQUEST_0_TAXAMT='.urlencode($TotalTaxAmount).
				'&PAYMENTREQUEST_0_SHIPPINGAMT='.urlencode($ShippinCost).
				'&PAYMENTREQUEST_0_HANDLINGAMT='.urlencode($HandalingCost).
				'&PAYMENTREQUEST_0_SHIPDISCAMT='.urlencode($ShippinDiscount).
				'&PAYMENTREQUEST_0_INSURANCEAMT='.urlencode($InsuranceCost).
				'&PAYMENTREQUEST_0_AMT='.urlencode($GrandTotal).
				'&PAYMENTREQUEST_0_CURRENCYCODE='.urlencode($PayPalCurrencyCode);
	
	//We need to execute the "DoExpressCheckoutPayment" at this point to Receive payment from user.
	$paypal= new MyPayPal();
	$httpParsedResponseAr = $paypal->PPHttpPost('DoExpressCheckoutPayment', $padata, $PayPalApiUsername, $PayPalApiPassword, $PayPalApiSignature, $PayPalMode);
	
	//Check if everything went ok..
	if("SUCCESS" == strtoupper($httpParsedResponseAr["ACK"]) || "SUCCESSWITHWARNING" == strtoupper($httpParsedResponseAr["ACK"])) 
	{
                   /* Only for testing puporse (Disabled )
			echo '<h2>Success</h2>';
			echo 'Your Transaction ID : '.urldecode($httpParsedResponseAr["PAYMENTINFO_0_TRANSACTIONID"]); */
			
				/*
				//Sometimes Payment are kept pending even when transaction is complete. 
				//hence we need to notify user about it and ask him manually approve the transaction
				*/
				
				if('Completed' == $httpParsedResponseAr["PAYMENTINFO_0_PAYMENTSTATUS"])
				{
					//echo '<div style="color:green">Payment Received! Your product will be sent to you very soon!</div>';
				}
				elseif('Pending' == $httpParsedResponseAr["PAYMENTINFO_0_PAYMENTSTATUS"])
				{
					echo '<div style="color:red">Transaction Complete, but payment is still pending! '.
					'You need to manually authorize this payment in your <a target="_new" href="http://www.paypal.com">Paypal Account</a></div>';
				}

				// we can retrive transection details using either GetTransactionDetails or GetExpressCheckoutDetails
				// GetTransactionDetails requires a Transaction ID, and GetExpressCheckoutDetails requires Token returned by SetExpressCheckOut
				$padata = 	'&TOKEN='.urlencode($token);
				$paypal= new MyPayPal();
				$httpParsedResponseAr = $paypal->PPHttpPost('GetExpressCheckoutDetails', $padata, $PayPalApiUsername, $PayPalApiPassword, $PayPalApiSignature, $PayPalMode);

				if("SUCCESS" == strtoupper($httpParsedResponseAr["ACK"]) || "SUCCESSWITHWARNING" == strtoupper($httpParsedResponseAr["ACK"])) 
				{
					
					//echo '<br /><b>Stuff to store in database :</b><br /><pre>';
					
					#### SAVE BUYER INFORMATION IN DATABASE ###
					//see (http://www.sanwebe.com/2013/03/basic-php-mysqli-usage) for mysqli usage
					
					$buyerName = $httpParsedResponseAr["FIRSTNAME"].' '.$httpParsedResponseAr["LASTNAME"];
					$buyerEmail = $httpParsedResponseAr["EMAIL"];
					
					//Open a new connection to the MySQL server
					include ("connection.php");								
					
					$con=new database();
		            $link=$con->getmyDB();
					print_r($link);
					if ($link) {echo 'WORKEDxxx';} else {echo 'FAILED';}
					//$link=$link->db_connect();

					//INSERT CUSTOMER DETAILS -first name, last name, email, username, password, country, country-code,area code, phone
				
				
					$first_name=$_SESSION["first_name"];
					$last_name=$_SESSION["last_name"];
					$email=	$_SESSION['email'];
					$password=	$_SESSION['password'];
					$country=$_SESSION['country']	;
					$country_code=$_SESSION['country_code'];
					$area_code=$_SESSION['area_code'];
					$phone_number=$_SESSION['phone_number'];
					$registration_date=$httpParsedResponseAr["TIMESTAMP"];
					
					



					
					
					if($insert_customer){
						
					$CUSTOMER_ID=$link->insert_id;  // the row inserted
					
					session_start();
					
						$_SESSION['username'] =$email;
						$_SESSION['password'] =$password;


					}
					
					else {
						die('Error customer detais : ('. $link->errno .') '. $link->error);
					}					
					
					//ORDER DETAILS
				
					$topic=$_SESSION["topic"];
					$customer_id=$CUSTOMER_ID;
					$date_placed=$httpParsedResponseAr["TIMESTAMP"];
					$type_of_document=$_SESSION["document_type"];
					$academic_level=$_SESSION["academic_level"];
					$urgency=$_SESSION["urgency"];
					$number_of_pages=$httpParsedResponseAr["L_QTY0"];
					$spacing=$_SESSION["spacing"];
					$cost_per_page=$httpParsedResponseAr["L_AMT0"];
					$reference_style=$_SESSION["reference_style"];
					$language=$_SESSION["language"];
					$description=$_SESSION["description"];
					$references=$_SESSION["references"];
					$subject=$_SESSION["subject"];
					$status="processing";
					
										
					$insert_order = $link->query("INSERT INTO `order_details`(
					
					`topic`,
					`customer_id`,
					`doctype`,
					`academic_level`,
					`urgency`,
					`number_of_pages`,
					`spacing`, 
					`amount`, 
					`style`, 
					`prefered_language`, 
					`order_description`,
					`number_of_reference`,
					`subject_area`,
					`processing`
					
					) 
					
					VALUES (				
					
					'$topic',
					'$customer_id',
					'$type_of_document',
					'$academic_level',
					
					'$urgency',
					'$number_of_pages',
					'$spacing',
					'$cost_per_page',
					'$reference_style',
					'$language',
					'$description',
					'$references',
					'$subject',
					'$status'
					
					
					)");
					
								
					if($insert_order){
						
					$the_order_id=$link->insert_id;  // the row inserted
					
					
					/*echo
					$topic.'--topic<br>cust id:'.
					$customer_id.'<br>doctype:'.
					$type_of_document.'<br>acaademic level:'.
					$academic_level.'<br>deadline:'.
					
					$urgency.'<br>pages:'.
					$number_of_pages.'<br>space:'.
					$spacing.'<br>cpp:'.
					$cost_per_page.'<br>style:'.
					$reference_style.'<br>language:'.
					$language.'<br>description:'.
					$description.'<br>reference:'.
					$references.'<br>subject:'.
					$subject
									
					;*/
					}
					
					else{
						die('Error : ('. $link->errno .') '. $link->error);
					}
					
					
									
					//INSERT BILLING DETAILS DETAILS
					
					$First_Name=$httpParsedResponseAr["FIRSTNAME"];
					$Last_Name=$httpParsedResponseAr["LASTNAME"];
					//paid from email
					$email=$httpParsedResponseAr["EMAIL"];
					$order_id=$the_order_id;
					$transaction_id=$httpParsedResponseAr["PAYMENTREQUESTINFO_0_TRANSACTIONID"];
					$amount=$httpParsedResponseAr["ITEMAMT"];
					$type="paypal";
					$customer_id=$CUSTOMER_ID;
					$date_of_transaction=$httpParsedResponseAr["TIMESTAMP"];
					
					
					$insert_bill=$link->query("INSERT INTO `billing`
					
					(
					
					`order_id`, 
					`transaction_id`,
					`amount`,
					`type`, 
					`customer_id`,
					`transaction_date`,
					`first_name`,
					`last_name`,
					`email`
					
					)
					
					VALUES 
					
					(
				
					'$order_id',
					'$transaction_id',
					'$amount',
					'$type',
					'$customer_id',
					'$date_of_transaction',
					'$First_Name',
					'$Last_Name',
					'$email'
					)					
					");
					
					
						if($insert_bill){
						
					$_SESSION['transaction_id']=$transaction_id;
					}
					
					else{
						die('Error : ('. $link->errno .') '. $link->error);
					}
					
				// Register $myusername, $mypassword and redirect to file "login_success.php"
					session_start();
					
					$_SESSION['client_username']=$email;
					$_SESSION['client_password']=$password;
					$_SESSION['client_id']=$CUSTOMER_ID;
					
					$message="Thank you  for placing an order with us. We will ensure you get a good grade.";
					$messagehead="Order successfully placed";
					$message_status="Not Read";
					$message_date=$httpParsedResponseAr["TIMESTAMP"];
					$type="Support";
					
					$sendmessage=$link->query("
					
					INSERT INTO `messages` (`sent_from_id`, `sent_to_id`, `content`, `message_head`, `order_id`, `status_general`, `date`, `sender_type`) 
					VALUES ('','$CUSTOMER_ID','$message','$messagehead','$order_id','$message_status','$message_date','$type')
					 "); 
					 
					

					
					header("location: ../../processing.php");
					
				} else  {
					echo '<div style="color:red"><b>GetTransactionDetails failed:</b>'.urldecode($httpParsedResponseAr["L_LONGMESSAGE0"]).'</div>';
					echo '<pre>';
					print_r($httpParsedResponseAr);
					echo '</pre>';

				}
	
	}else{
			echo '<div style="color:red"><b>Error : </b>'.urldecode($httpParsedResponseAr["L_LONGMESSAGE0"]).'</div>';
			echo '<pre>';
			print_r($httpParsedResponseAr);
			echo '</pre>';
	}
}
?>
