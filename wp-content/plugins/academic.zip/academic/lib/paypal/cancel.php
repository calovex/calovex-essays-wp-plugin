<?php

echo "Sorry, you decided to cancel the order, you can always place an order throug this";

?>