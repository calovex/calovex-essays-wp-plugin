<?php

function my_account() {

get_sidebar('left');



echo 'I just made it again
<a href="#">My Profile</a>
<a href="#">My orders</a>
<a href="#">Messsages</a>
<a href="#">Payments</a>
<a href="#">FAQS</a>';



get_sidebar('');


	
	
	
}