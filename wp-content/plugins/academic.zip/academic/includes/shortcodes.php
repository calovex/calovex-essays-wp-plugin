<?php
defined( 'ABSPATH' ) || exit;


//include the required files
require_once 'C:\wamp642\www\client_plugin\wp-content\plugins\academic/templates/client/myaccount/orders.php'; 


//Calls frontend client navigation 



//client shortcodes
add_shortcode('ManagexOrder','my_account');