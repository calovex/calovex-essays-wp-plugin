<?php
/**
 * Plugin Name: Client Freelance Platform
 * Plugin URI: http://www.alexovey.com/freelance-plugin
 * Description: Free plugin for people wanting to start academic freelance websites
 * Version: 1.0
 * Author: Alex Ovey
 * Author URI: http://www.alexovey.com
 */
 

 //Retrieve all the required files
 $path=preg_replace('/wp-content.*$/','',__DIR__);
//echo $path;
require_once $path.'/wp-admin/includes/post.php';
require_once 'templates/order-form.php';
require_once 'includes/shortcodes.php';
require_once 'lib/admin/admin_dashboard.php';


//Register and load styles and scripts
//The scripts and styles must be loaded before they are enqueued
function init_method_t(){
	//registering javascript and css
	wp_register_script('order_calculator',plugins_url('js/ordercal.js',__FILE__),array(), false, true);
	wp_register_script('order_form_style_js',plugins_url('js/order_form_style_js.js',__FILE__),array(), false, true);
	
	wp_register_style('order_form',plugins_url('css/order_form_style.css',__FILE__));
	wp_register_style('order_formx','https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
	wp_register_style('extcss','https://fonts.googleapis.com/css?family=Raleway');
	
	wp_register_script('scriptx','https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js');
	wp_register_script('scripty','https://www.jqueryscript.net/demo/Creating-A-Modern-Multi-Step-Form-with-jQuery-CSS3/js/jquery.easing.min.js">
');
	
}

function enqueue_scripts_and_styles (){
	//enquing scripts and styles
	wp_enqueue_script('order_calculator');
	wp_enqueue_script('order_form_style_js');
	
	wp_enqueue_script('scriptx');
	wp_enqueue_script('scripty');
	wp_enqueue_style('order_formx');
	wp_enqueue_style('order_form');
	wp_enqueue_style('extcss');
	
	 	
}

add_action('init','init_method_t'); 
add_action('wp_enqueue_scripts','enqueue_scripts_and_styles');
add_action( 'init','ovey_academic_order_page' ); 




//SHORTCODES clients 

add_shortcode('PlacexOrder','create_order_form');




//SHORTCODES admin


//call to create page 
//ovey_academic_order_page($title,$content,$type); 

function ovey_academic_order_page() {
	
	// create order page 

	// Create place order page 
	$title='Place Order';
	$content='[PlacexOrder]';
	$type='page';
	
	
   if (!post_exists($title,$content,$date,$type)){
		$my_post = array(
		  'post_title'    => 'Place Order',
		  'post_content'  => '[PlacexOrder]',
		  'post_status'   => 'publish',
		  'post_author'   => 1,
		  'post_type'   => 'page',
		  'post_category' => array( 8,39 ));
   
		 
		// Insert the post into the database
		wp_insert_post( $my_post );
		} else {};
}		

// Creating the order form  
function create_order_form (){
	$content=ovey_order_form();
	//$content=plugins_url('css/order_form_style.css',__FILE__);
	return $content;
	
}


function beloxx()
{
		$args = array(
    'post_type'      => 'book',
    'posts_per_page' => 3,
		);
		$loop = new WP_Query($args);
		while ( $loop->have_posts() ) {
			$loop->the_post();
			?>
			<div class="entry-content">
				<?php the_title(); ?>
				<?php the_content(); ?>
			</div>
			<?php
		}

	echo '[Formx1]';
}
//Register custom menu page
function ovey_custom_menu()
{
	add_menu_page(
	'My Menu Page',
	'My Menu',
	'manage_options',
	'menuslxug',
	'belox',
	'',
	'',
	6
	);
	add_submenu_page(
	'menuslxug',
	'My Menu Page 1',
	'My Menu 1.2',
	'manage_options',
	'menuslxugx',
	'beloxx',
	'',
	'',
	1
	);
}
add_action('admin_menu','ovey_custom_menu');

/**
 * Register a custom post type called "book".
 *
 * @see get_post_type_labels() for label keys.
 */
function wpdocs_codex_book_init() {
    $labels = array(
        'name'                  => _x( 'Books', 'Post type general name', 'textdomain' ),
        'singular_name'         => _x( 'Book', 'Post type singular name', 'textdomain' ),
        'menu_name'             => _x( 'Books', 'Admin Menu text', 'textdomain' ),
        'name_admin_bar'        => _x( 'Book', 'Add New on Toolbar', 'textdomain' ),
        'add_new'               => __( 'Add New', 'textdomain' ),
        'add_new_item'          => __( 'Add New Book', 'textdomain' ),
        'new_item'              => __( 'New Book', 'textdomain' ),
        'edit_item'             => __( 'Edit Book', 'textdomain' ),
        'view_item'             => __( 'View Book', 'textdomain' ),
        'all_items'             => __( 'All Books', 'textdomain' ),
        'search_items'          => __( 'Search Books', 'textdomain' ),
        'parent_item_colon'     => __( 'Parent Books:', 'textdomain' ),
        'not_found'             => __( 'No books found.', 'textdomain' ),
        'not_found_in_trash'    => __( 'No books found in Trash.', 'textdomain' ),
        'featured_image'        => _x( 'Book Cover Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'textdomain' ),
        'set_featured_image'    => _x( 'Set cover image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
        'remove_featured_image' => _x( 'Remove cover image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
        'use_featured_image'    => _x( 'Use as cover image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'textdomain' ),
        'archives'              => _x( 'Book archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'textdomain' ),
        'insert_into_item'      => _x( 'Insert into book', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'textdomain' ),
        'uploaded_to_this_item' => _x( 'Uploaded to this book', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'textdomain' ),
        'filter_items_list'     => _x( 'Filter books list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'textdomain' ),
        'items_list_navigation' => _x( 'Books list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'textdomain' ),
        'items_list'            => _x( 'Books list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'textdomain' ),
    );
 
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'book' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' ),
    );
 
    register_post_type( 'book', $args );
}
 
add_action( 'init', 'wpdocs_codex_book_init' );



function formx()
{
	$form='
			 
				 <form method="POST" action="'.plugin_dir_url(__FILE__).'process/index.php" name="addBook" id="addBook">
  <div class="row mb-3">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Book Title</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="bookTitle" name="bookTitle">
    </div>
  </div>
  
  <div class="row mb-3">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Year of Publishing</label>
    <div class="col-sm-10">
      <input type="number" class="form-control" id="yearOfPublish" name="yearOfPublish">
    </div>
  </div>
  
  
  <div class="row mb-3">
    <label for="inputEmail3" class="col-sm-2 col-form-label">ISBN</label>
    <div class="col-sm-10">
      <input type="number" class="form-control" id="ISBN" name="ISBN">
    </div>
  </div>
  
  <div class="row mb-3">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Publisher</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="publisher" name="publisher" >
    </div>
  </div>
  
  <div class="row mb-3">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Category</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="category" name="category"> 
    </div>
  </div>
  
   
  <div class="row mb-3">
    <div class="col-sm-10 offset-sm-2">
      <div class="form-check">
        <input class="form-check-input" type="checkbox" id="gridCheck1">
        <label class="form-check-label" for="gridCheck1">
         I agree that the details are accurate
        </label>
      </div>
    </div>
  </div>
  <button type="submit" class="btn btn-primary" name="addBook" id="addBook">ADD BOOK</button>
</form>		
	';

return $form;	
}

add_shortcode('Formx1','formx');


 
 